package com.cn.homeControlSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeControlSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeControlSystemApplication.class, args);
	}

}
